// -*- mode: cpp; mode: fold -*-
// Description                                                          /*{{{*/
// $Id: ffs2_fs_i.h,v 1.1 2000/03/27 07:14:15 dwmw2 Exp $
/* ######################################################################

   Microsoft Flash File System 2 

   ##################################################################### */
									/*}}} */
#ifndef __LINUX_FFS2FS_FS_I_H
#define __LINUX_FFS2FS_FS_I_H

// Kernel Inode data
struct ffs2_inode_info 
{
};

#endif
