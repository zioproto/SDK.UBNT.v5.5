#define BIT_DIVIDER 1043 
static int bits[9] = { 277,249,290,267,229,341,212,241,};
